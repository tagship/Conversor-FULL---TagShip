// ------------------------------------------------------------
// TagShip — fondo de la extensión
// 1) Escucha cuando Correo Argentino genera un PDF y guarda cómo se pidió
//    (método, datos del formulario), para poder pedirlo de nuevo igual.
// 2) Al tocar el ícono: consigue el PDF de la pestaña y la reemplaza
//    por la versión 100x150, en la misma pestaña.
// ------------------------------------------------------------

const CORREO = ['https://*.correoargentino.com.ar/*'];
const TIMEOUT = 20000;

// ---------- 1. Captura del pedido original ----------
chrome.webRequest.onBeforeRequest.addListener(
  (d) => {
    if (d.tabId < 0) return;
    const req = { url: d.url, method: d.method, t: Date.now() };
    if (d.requestBody) {
      if (d.requestBody.formData) req.formData = d.requestBody.formData;
      else if (d.requestBody.raw) {
        const parts = d.requestBody.raw.filter((p) => p.bytes).map((p) => new Uint8Array(p.bytes));
        if (parts.length) req.raw = toB64(concat(parts));
      }
    }
    chrome.storage.session.set({ ['req_' + d.tabId]: req });
  },
  { urls: CORREO, types: ['main_frame', 'sub_frame'] },
  ['requestBody']
);

chrome.webRequest.onBeforeSendHeaders.addListener(
  async (d) => {
    if (d.tabId < 0) return;
    const ct = (d.requestHeaders || []).find((h) => h.name.toLowerCase() === 'content-type');
    if (!ct) return;
    const key = 'req_' + d.tabId;
    const s = await chrome.storage.session.get(key);
    if (s[key] && s[key].url === d.url) {
      s[key].contentType = ct.value;
      chrome.storage.session.set({ [key]: s[key] });
    }
  },
  { urls: CORREO, types: ['main_frame', 'sub_frame'] },
  ['requestHeaders']
);

// ---------- 2. Clic en el ícono ----------
chrome.action.onClicked.addListener(async (tab) => {
  const src = tab.url || '';
  badge('…');

  const job = { src, at: Date.now() };
  try {
    const bytes = await getPdf(tab);
    job.pdf = toB64(bytes);
  } catch (e) {
    job.error = String((e && e.message) || e);
  }

  // Guardamos sólo el último trabajo
  const all = await chrome.storage.session.get(null);
  const old = Object.keys(all).filter((k) => k.startsWith('job_'));
  if (old.length) await chrome.storage.session.remove(old);
  const id = 'job_' + Date.now();
  await chrome.storage.session.set({ [id]: job });

  const viewer = chrome.runtime.getURL('viewer.html') + '#' + id;
  const looksLikePdf = /getpdf|\.pdf(\?|#|$)/i.test(src) || !!job.pdf;

  if (looksLikePdf) {
    await chrome.tabs.update(tab.id, { url: viewer }); // misma pestaña
  } else {
    // No estaba en una etiqueta: no le pisamos la página, mostramos el aviso aparte
    await chrome.tabs.create({ url: viewer, index: tab.index + 1 });
  }
  badge('');
});

// ---------- Cómo conseguir el PDF ----------
async function getPdf(tab) {
  const src = tab.url || '';
  if (!/^https?:\/\//i.test(src)) throw new Error('NO_PDF_TAB');

  const tries = [];
  const key = 'req_' + tab.id;
  const saved = (await chrome.storage.session.get(key))[key];

  // a) Repetir el pedido original (si fue un formulario POST)
  if (saved && saved.url === src && saved.method && saved.method !== 'GET') {
    try {
      return await fetchPdf(src, buildInit(saved));
    } catch (e) { tries.push('repetir ' + saved.method + ': ' + e.message); }
  }

  // b) Pedirlo de nuevo con la sesión del usuario
  try {
    return await fetchPdf(src, { method: 'GET', credentials: 'include' });
  } catch (e) { tries.push('GET: ' + e.message); }

  // c) Pedirlo desde adentro de la propia pestaña
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        const r = await fetch(location.href, { credentials: 'include' });
        const b = new Uint8Array(await r.arrayBuffer());
        let s = '';
        for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
        return { ok: r.ok, status: r.status, b64: btoa(s) };
      },
    });
    const v = res && res.result;
    if (!v || !v.ok) throw new Error('HTTP ' + (v ? v.status : '?'));
    const bytes = fromB64(v.b64);
    if (!isPdf(bytes)) throw new Error('la respuesta no es un PDF');
    return bytes;
  } catch (e) { tries.push('pestaña: ' + e.message); }

  if (!saved) tries.push('sin pedido capturado (¿la extensión estaba instalada cuando se generó la etiqueta?)');
  throw new Error(tries.join(' | '));
}

function buildInit(saved) {
  const init = { method: saved.method, credentials: 'include' };
  if (saved.formData) {
    const p = new URLSearchParams();
    for (const [k, vals] of Object.entries(saved.formData)) for (const v of vals) p.append(k, v);
    init.body = p;
  } else if (saved.raw) {
    init.body = fromB64(saved.raw);
    if (saved.contentType) init.headers = { 'Content-Type': saved.contentType };
  }
  return init;
}

async function fetchPdf(url, init) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT);
  try {
    const r = await fetch(url, { ...init, cache: 'no-store', signal: ctrl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const bytes = new Uint8Array(await r.arrayBuffer());
    if (!isPdf(bytes)) throw new Error('la respuesta no es un PDF (' + (r.headers.get('content-type') || 'sin tipo') + ')');
    return bytes;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('tardó demasiado');
    throw e;
  } finally { clearTimeout(t); }
}

// ---------- utilidades ----------
function isPdf(b) {
  const head = String.fromCharCode.apply(null, b.subarray(0, 1024));
  return head.includes('%PDF-');
}
function concat(parts) {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let o = 0; for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}
function toB64(b) {
  let s = '';
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(s);
}
function fromB64(s) {
  const bin = atob(s); const b = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
  return b;
}
function badge(text) {
  chrome.action.setBadgeBackgroundColor({ color: '#024FEB' });
  chrome.action.setBadgeText({ text });
}
