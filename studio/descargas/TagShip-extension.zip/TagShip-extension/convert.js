// TagShip — convierte etiquetas A4 de Correo Argentino (MiCorreo / PAQ.AR) a 100x150 mm.
// Funciona con cualquier cantidad de páginas: una etiqueta por página.

const MM = 72 / 25.4;
const OUT_W = 100 * MM; // 283.46 pt
const OUT_H = 150 * MM; // 425.20 pt
const MARGIN = 2 * MM;

// Recuadro de la etiqueta medido desde la esquina superior izquierda de la hoja (en puntos)
const LABEL = { left: 56.69, top: 59.53, right: 300.47, bottom: 521.57 };
const PAD = 2; // un poquito de aire para no comerse el borde

async function convertToTagship(bytes) {
  const { PDFDocument } = PDFLib;
  const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
  const out = await PDFDocument.create();
  const pages = src.getPages();
  if (!pages.length) throw new Error('El PDF no tiene páginas.');

  for (const page of pages) {
    const { width: w, height: h } = page.getSize();

    let box;
    if (w < 450 && h < 650) {
      // Ya es una etiqueta chica: se usa entera
      box = { left: 0, bottom: 0, right: w, top: h };
    } else {
      box = {
        left: Math.max(0, LABEL.left - PAD),
        right: Math.min(w, LABEL.right + PAD),
        top: Math.min(h, h - LABEL.top + PAD),
        bottom: Math.max(0, h - LABEL.bottom - PAD),
      };
    }

    const embedded = await out.embedPage(page, box);
    const bw = box.right - box.left;
    const bh = box.top - box.bottom;
    const scale = Math.min((OUT_W - 2 * MARGIN) / bw, (OUT_H - 2 * MARGIN) / bh);
    const dw = bw * scale;
    const dh = bh * scale;

    const p = out.addPage([OUT_W, OUT_H]);
    p.drawPage(embedded, {
      x: (OUT_W - dw) / 2,
      y: (OUT_H - dh) / 2,
      width: dw,
      height: dh,
    });
  }

  out.setTitle('Etiquetas TagShip 100x150');
  out.setCreator('Extensión TagShip');
  return { bytes: await out.save(), count: pages.length };
}

if (typeof module !== 'undefined') module.exports = { convertToTagship };
