const $ = (id) => document.getElementById(id);

function fail(title, msg, detail) {
  $('status').classList.add('error');
  $('title').textContent = title;
  $('msg').textContent = msg;
  if (detail) { $('detail').hidden = false; $('detail').textContent = 'Detalle: ' + detail; }
  $('retry').hidden = history.length < 2;
}
$('retry').addEventListener('click', () => history.back());

function fromB64(s) {
  const bin = atob(s); const b = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
  return b;
}

async function run() {
  const id = location.hash.slice(1);
  const job = id ? (await chrome.storage.session.get(id))[id] : null;

  if (!job) {
    return fail('No hay ninguna etiqueta para adaptar',
      'Abrí la etiqueta A4 de Correo Argentino y tocá el ícono de TagShip desde esa pestaña.');
  }
  if (job.error === 'NO_PDF_TAB' || (!job.pdf && !/getpdf|\.pdf/i.test(job.src || ''))) {
    return fail('Esta pestaña no es una etiqueta',
      'Tocá el ícono de TagShip estando en la pestaña donde se ve la etiqueta A4 de Correo Argentino.');
  }
  if (!job.pdf) {
    return fail('No pudimos leer la etiqueta',
      'Generá la etiqueta otra vez desde PAQ.AR o MiCorreo y, apenas se abra, tocá el ícono de TagShip.',
      job.error);
  }

  let result;
  try {
    result = await convertToTagship(fromB64(job.pdf));
  } catch (e) {
    return fail('No pudimos adaptar este PDF', 'El archivo parece dañado o protegido. Generá la etiqueta otra vez.', String(e.message || e));
  }

  const n = result.count;
  const url = URL.createObjectURL(new Blob([result.bytes], { type: 'application/pdf' }));

  document.title = `TagShip · ${n} ${n === 1 ? 'etiqueta' : 'etiquetas'} 100x150`;
  $('ready').textContent = n === 1 ? 'Etiqueta lista' : `${n} etiquetas listas`;
  $('count').textContent = n === 1 ? 'Adaptada a 100x150 mm.' : `Una por hoja, adaptadas a 100x150 mm.`;

  $('status').hidden = true;
  $('result').hidden = false;
  $('actions').hidden = false;

  const frame = $('frame');
  const printNow = () => { try { frame.contentWindow.focus(); frame.contentWindow.print(); } catch (_) {} };
  frame.addEventListener('load', () => setTimeout(printNow, 700), { once: true });
  frame.src = url;

  $('print').addEventListener('click', printNow);
  $('print2').addEventListener('click', printNow);
  $('back').addEventListener('click', () => history.back());
  $('download').addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = url;
    a.download = `etiquetas-tagship-${new Date().toISOString().slice(0, 10)}.pdf`;
    a.click();
  });
}

run();
